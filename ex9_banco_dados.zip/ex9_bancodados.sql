create database aula;
use aula;
 
 create table projeto (id_projeto int primary key auto_increment,
 nome_projeto varchar(30),
 descricao_projeto varchar(60)
 );
 
 insert into projeto values
 (null,'vaca leiteira','estudo para minimizar a perda do leite'),
 (null,'energia eletrica','estudo para minimizar a perda de energia'),
 (null,'agua e o mundo','estudo para minimizar a perda de agua');
 
 create table aluno (ra int primary key,
nome_aluno varchar(30),
telefone bigint,
FK_projeto int,
foreign key (FK_projeto) references projeto (id_projeto)
);

insert into aluno values
(01192088,'igor',964453399,1),
(01192084,'pedro',967456469,3),
(01192008,'angelo',956734775,2);

create table convidados(id_conv int primary key auto_increment,
nome_conv varchar(30),
tipo_relaçao varchar(30),
FK_aluno int,
foreign key (FK_aluno) references aluno (ra)
);

insert into convidados values
(null,'agenor','pai',01192088),
(null,'maria','mae',01192008),
(null,'barbara','irma',01192084);
 
 select * from aluno;